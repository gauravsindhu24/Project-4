<?php 

$this->load->view('layout/includes/header');
$this->load->view('layout/includes/navbar');
$this->load->view($content);
$this->load->view('layout/includes/footer');

 ?>