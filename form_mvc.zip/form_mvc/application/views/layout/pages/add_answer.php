<?= form_open('site/submit_answer'); ?>
<div class="container">
    <div class="row">
    <?php if($this->session->flashdata('ans_msg') !=null ): ?>
        <div class="alert alert-success" role="alert">
            <center><?= $this->session->flashdata('ans_msg'); ?></center>
        </div>
    <?php endif; ?>
    <?php if($this->session->flashdata('ans_err') !=null ): ?>
        <div class="alert alert-danger" role="alert">
            <center><?= $this->session->flashdata('ans_err'); ?></center>
        </div>
    <?php endif; ?>
    <div class="col-md-6">
      <h2>Welcome: <?= ucfirst($this->session->userdata('f_name')) . " " . ucfirst($this->session->userdata('l_name')); ?></h2>
     <br>
    </div>
    <div class="col-md-6">
     <div class="pull-right" style="padding-top: 29px;">
     <a href="<?= base_url(); ?>site/display_questions" class="btn btn-info">Own Questions</a> | <a href="<?= base_url(); ?>site/display_all_questions" class="btn btn-primary">All Questions</a>
     </div>
    </div>
    </div>           
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>Questions Name</th>
        <th>Questions Body</th>
        <th>Questions Skills</th>
      </tr>
    </thead>
    <tbody>
    <?php ;
    ?>
    <?php if(isset($all_ques)): ?>
    <?php foreach($all_ques as $question): ?>
      <tr>
        <td><?= $question->ques_name; ?></td>
        <td><?= $question->ques_body; ?></td>
        <td><?= $question->ques_skills; ?></td>
      </tr>
    <?php endforeach; ?>
    <?php endif;  ?>
    <tr>
        <td colspan="3"><strong>Answers:</strong></td>
    </tr>
    <?php if(isset($all_ans)): ?>
    <?php foreach($all_ans as $answers): ?>
      <tr>
        <td colspan="2" width="80%"><?= $answers->answer; ?></td>
        <td>
            <center>
            (<?= isset($answers->total_like) ? $answers->total_like : 0; ?>) 
            <a href="<?= base_url(); ?>site/like/<?= $answers->ques_id; ?>/<?= $answers->ans_id; ?>"><i class="fa fa-thumbs-up"></i></a> | 
            <a href="<?= base_url(); ?>site/dislike/<?= $answers->ques_id; ?>/<?= $answers->ans_id; ?>"><i class="fa fa-thumbs-down"></i></a> 
            (<?= isset($answers->total_dislike) ? $answers->total_dislike : 0; ?>)
            </center>
        </td>
      </tr>
    <?php endforeach; ?>
    <?php endif;  ?>

    </tbody>
  </table>
  <div class="col-md-12">
  <input type="hidden" name="question_id" value="<?= $this->uri->segment(3); ?>">
    <textarea name="answer" id="" cols="30" rows="10" class="form-control" autofocus></textarea>
    <br>
    <center>
         <input type="submit" value="Add Answer" class="btn btn-success">
    </center>
  </div>
</div>
<?= form_close(); ?>