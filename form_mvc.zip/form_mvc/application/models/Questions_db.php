<?php 

class Questions_db extends CI_Model
{
    public function insert_ques($data)
    {
        $this->db->insert('tbl_questions', $data);
        return true;
    }

    public function newAnswer($data)
    {
        $this->db->insert('tbl_answers', $data);
        return true;
    }

    public function insert_like($data)
    {
        $this->db->insert('tbl_ans_count', $data);
        return true;
    }

    public function check_like($ans_id)
    {
        $this->db->where('ans_id', $ans_id);
        $this->db->where('like', 1);
        // $this->db->or_where('dislike', 1);
        $this->db->where('count_user_id', $this->session->userdata('user_id'));
        $query = $this->db->get('tbl_ans_count');
        if($query->num_rows() > 0)
		{
			return $query->result();
		}
    }

    public function check_dislike($ans_id)
    {
        $this->db->where('ans_id', $ans_id);
        $this->db->where('dislike', 1);
        $this->db->where('count_user_id', $this->session->userdata('user_id'));
        $query = $this->db->get('tbl_ans_count');
        if($query->num_rows() > 0)
		{
			return $query->result();
		}
    }

    public function get_questions()
    {
        $this->db->where('get_user_id', $this->session->userdata('user_id'));
        $query = $this->db->get('tbl_questions');
        return $query->result();
    }

    public function get_all_questions()
    {
        $query = $this->db->get('tbl_questions');
        return $query->result();
    }

    public function getAnswer($id)
    {
        $this->db->where('ques_id', $id);
        $query = $this->db->get('tbl_questions');
        return $query->result();
    }

    public function get_answer($id)
    {
        $this->db->order_by('total_like',"desc");
        $this->db->where('ques_id', $id);
        $query = $this->db->get('tbl_answers');
        return $query->result();
    }

    public function del_questions()
    {
        $this->db->where('ques_id', $this->uri->segment(3));
        $this->db->delete('tbl_questions');
        return true;
    }

    public function edit_questions($id)
    {
        $this->db->where('ques_id', $id);
        $query = $this->db->get('tbl_questions');
        return $query->result();
    }

    public function update_questions($ques_id, $data)
    {
        $this->db->where('ques_id', $ques_id);
        $query = $this->db->update('tbl_questions', $data);
        return true;
    }
    
}

?>