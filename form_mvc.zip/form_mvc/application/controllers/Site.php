<?php 

class Site extends CI_Controller
{
    function __construct()
    {
        Parent::__construct();
        $this->load->model('accounts_db');
        $this->load->model('questions_db');
    }

    public function login()
    {
        $this->load->view('layout/pages/login');
    }

    public function register()
    {
        $this->load->view('layout/pages/register');
    }

    public function display_questions()
    {
        $data['all_ques'] = $this->questions_db->get_questions();
        $data['content'] = 'layout/pages/view_questions';
        $this->load->view('site_template', $data);
    }

    public function create_new_question()
    {
        $data['content'] = 'layout/pages/questions';
        $this->load->view('site_template', $data);
    }

    public function display_edit_question($id)
    {
        $data['get_ques'] = $this->questions_db->edit_questions($id);
        $data['content'] = 'layout/pages/edit_questions';
        $this->load->view('site_template', $data);
    }

    public function edit_question()
    {
        $ques_id = $this->input->post('ques_id');
        $data = array(
            'ques_name' => $this->input->post('ques_name'),
            'ques_body' => $this->input->post('ques_body'),
            'ques_skills'  => $this->input->post('ques_skills'),
            'get_user_id'  => $this->session->userdata('user_id'),

           );
        $this->questions_db->update_questions($ques_id, $data);
        $this->session->set_flashdata('ques_msg','Questions has been updated');
        redirect('site/display_questions');
    }

    public function delete_question()
    {
        $this->questions_db->del_questions();
        $this->session->set_flashdata('del_ques','Question has been deleted');
		redirect('site/display_questions');
    }

    public function create_register()
	{
        $this->form_validation->set_rules('Fname', 'First Name', 'required');
        $this->form_validation->set_rules('Lname', 'Last Name', 'required');
        $this->form_validation->set_rules('bday', 'BirthDay Confirmation', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[tbl_users.email]');

        if ($this->form_validation->run() == FALSE)
            {
                $data['content'] = 'layout/pages/register';
                $this->load->view('site_template', $data);
            }
        else
            {
                $data = array(
                    'f_name' => $this->input->post('Fname'),
                    'l_name' => $this->input->post('Lname'),
                    'b_day'  => $this->input->post('bday'),
                    'email'  => $this->input->post('email'),
                    'pass'   => $this->input->post('password'),

                   );
                $this->accounts_db->insert_reg($data);
                $this->session->set_flashdata('message','User  has been registered successfully');
                redirect('site/register');
            }

    }

    public function add_questions()
	{
		$data = array(
						'ques_name' => $this->input->post('ques_name'),
						'ques_body' => $this->input->post('ques_body'),
                        'ques_skills'  => $this->input->post('ques_skills'),
                        'get_user_id'  => $this->session->userdata('user_id'),

			           );
        $this->questions_db->insert_ques($data);
        $this->session->set_flashdata('ques_msg','Questions has been created');
		redirect('site/create_new_question');

    }

    public function validate_credentails()
	{
		$query = $this->accounts_db->validate();
		if($query)
		{
			$data = array(
						  'email'       => $this->input->post('email'),
                          'f_name'   => $query[0]->f_name,
                          'l_name'   => $query[0]->l_name,
                          'user_id'   => $query[0]->user_id,
						  'is_login_in' => true,
						   );
			$this->session->set_userdata($data);
			redirect('site/display_questions');
		}
		else
		{
            $this->session->set_flashdata('login_error','Wrong username or password');
            redirect('site/login');
		}
    }
    
    public function display_all_questions()
    {
        $data['all_ques'] = $this->questions_db->get_all_questions();
        $data['content'] = 'layout/pages/view_questions';
        $this->load->view('site_template', $data);
    }

    public function add_answer($id)
    {
        $data['all_ques'] = $this->questions_db->getAnswer($id);
        $data['all_ans'] = $this->questions_db->get_answer($id);
        $data['content'] = 'layout/pages/add_answer';
        $this->load->view('site_template', $data);
    }

    public function submit_answer()
	{
		$data = array(
						'ques_id' => $this->input->post('question_id'),
						'answer' => $this->input->post('answer'),
                        'ans_user_id' => $this->session->userdata('user_id'),

			           );
        $this->questions_db->newAnswer($data);
        $this->session->set_flashdata('ans_msg','Answer has been submitted');
        $url = base_url() . "site/add_answer/". $data['ques_id'];
		redirect($url);

    }

    public function like($ques_id, $ans_id)
    {
        $check_value = $this->questions_db->check_like($ans_id);
        if(isset($check_value))
        {
            $this->session->set_flashdata('ans_err','You have already vote this answer');
            $url = base_url() . "site/add_answer/". $ques_id;
            redirect($url);
        }
        else{
            $data = array(
                'ans_id' => $ans_id,
                'like' => 1,
                'dislike' => 0,
                'count_user_id' => $this->session->userdata('user_id'),
    
               );
            $result = $this->questions_db->insert_like($data);
            if($result)
            {
                $this->db->set('total_like', 'total_like+1', FALSE);
                $this->db->where('ans_id', $ans_id);
                $this->db->update('tbl_answers');
            }
            $this->session->set_flashdata('ans_msg','You vote this answer');
            $url = base_url() . "site/add_answer/". $ques_id;
            redirect($url);
        }
    }

    public function dislike($ques_id, $ans_id)
    {
        $check_value = $this->questions_db->check_like($ans_id);
        if(isset($check_value))
        {
            $this->session->set_flashdata('ans_err','You have already vote this answer');
            $url = base_url() . "site/add_answer/". $ques_id;
            redirect($url);
        }
        else{
            $data = array(
                'ans_id' => $ans_id,
                'like' => 0,
                'dislike' => 1,
                'count_user_id' => $this->session->userdata('user_id'),
    
               );
            $result = $this->questions_db->insert_like($data);
            if($result)
            {
                $this->db->set('total_dislike', 'total_dislike+1', FALSE);
                $this->db->where('ans_id', $ans_id);
                $this->db->update('tbl_answers');

                $this->db->where('ans_id', $ans_id);
                $this->db->where('like', 1);
                $this->db->where('count_user_id', $this->session->userdata('user_id'));
                $this->db->delete('tbl_ans_count');
            }
            $this->session->set_flashdata('ans_msg','You dis vote this answer');
            $url = base_url() . "site/add_answer/". $ques_id;
            redirect($url);
        }
    }

	public function logout()
	{
		$this->session->sess_destroy();
        redirect('site/login');
	}

    
}

?>